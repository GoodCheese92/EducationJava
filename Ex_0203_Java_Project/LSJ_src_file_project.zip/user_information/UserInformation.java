package user_information;

public class UserInformation {
	private int id;
	private int password;

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public int getPassword() {
		return password;
	}

	public void setPassword(int password) {
		this.password = password;
	}

	
} // end of class
