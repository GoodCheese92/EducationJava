package menu_frame;

import javax.swing.JFrame;

public class UpperMenubarFrame extends JFrame {
	public UpperMenubarFrame() {
		
		
		setVisible(true);
	} // end of constructor
	
} // end of class
