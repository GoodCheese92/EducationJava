package test_ttt;

import java.util.ArrayList;

public class TestArrayList {
	
	
	
	public static void main(String[] args) {
		Add a = new Add();
		a.add(1, 2);
	
	
	
	} // end of main
} // end of class

class Add {
	public void add(int x, int y) {
		System.out.println(x+y);
	}
}